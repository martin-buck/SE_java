import java.util.*;

public class SimJSON {
    HashMap<String, List<String>> lines = new HashMap<String, List<String>>();
    HashMap<String, List<String>> trips = new HashMap<String, List<String>>();
}
