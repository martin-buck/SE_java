interface BoardInternalIterator {
    void visit(String loc, Piece p);
}